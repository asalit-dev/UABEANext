﻿using AssetsTools.NET;
using AssetsTools.NET.Extra;
using CommunityToolkit.Mvvm.ComponentModel;
using DynamicData;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using UABEANext4.AssetWorkspace;
using UABEANext4.Interfaces;

namespace UABEANext4.ViewModels.Dialogs;

public partial class SelectTypeFilterViewModel : ViewModelBase, IDialogAware<IEnumerable<TypeFilterTypeEntry>?>
{
    [ObservableProperty]
    public ObservableCollection<TypeFilterTypeEntry> _filterTypes = [];

    public string Title => "Select Type Filter";
    public int Width => 400;
    public int Height => 500;

    public bool IsModal => false;

    public event Action<IEnumerable<TypeFilterTypeEntry>?>? RequestClose;

    public SelectTypeFilterViewModel(List<TypeFilterTypeEntry> filterTypes)
    {
        FilterTypes.AddRange(filterTypes);
    }

    public void SelectAll()
    {
        foreach (var filterType in FilterTypes)
        {
            filterType.IsSelected = true;
        }
    }

    public void DeselectAll()
    {
        foreach (var filterType in FilterTypes)
        {
            filterType.IsSelected = false;
        }
    }

    public void Accept()
    {
        bool includeAllMonoBehaviours = false;

        var monoBehaviourType = FilterTypes.FirstOrDefault(ft => ft.TypeId == 0x72 && ft.ScriptRef is null);
        if (monoBehaviourType is not null)
            includeAllMonoBehaviours = monoBehaviourType.IsSelected;

        IEnumerable<TypeFilterTypeEntry> filteredTypes;
        if (includeAllMonoBehaviours)
            filteredTypes = FilterTypes.Where(ft => ft.IsSelected || ft.ScriptRef is not null);
        else
            filteredTypes = FilterTypes.Where(ft => ft.IsSelected);

        RequestClose?.Invoke(filteredTypes);
    }

    public void Cancel()
    {
        RequestClose?.Invoke(null);
    }

    public static List<TypeFilterTypeEntry> MakeTypeFilterTypes(Workspace workspace, IList<AssetInst> assets)
    {
        var uniqueTypeIds = new HashSet<int>();
        var uniqueMonoIdPairs = new Dictionary<AssetsFileInstance, HashSet<ushort>>();
        var uniqueScriptPtrs = new HashSet<AssetPPtr>();
        foreach (var asset in assets)
        {
            var typeId = asset.TypeId;
            // if a non-script or a script with no script binding, treat as regular type
            if (typeId != (int)AssetClassID.MonoBehaviour && typeId >= 0)
            {
                uniqueTypeIds.Add(typeId);
            }
            else
            {
                var assetFileInst = asset.FileInstance;
                var scriptIndex = asset.GetScriptIndex(assetFileInst.file);
                if (scriptIndex == ushort.MaxValue)
                {
                    uniqueTypeIds.Add(typeId);
                }
                else
                {
                    // a bit slow but I don't know what else to do
                    if (!uniqueMonoIdPairs.TryGetValue(assetFileInst, out HashSet<ushort>? value))
                        uniqueMonoIdPairs[assetFileInst] = value = [];

                    uniqueTypeIds.Add(0x72);
                    value.Add(scriptIndex);
                }
            }
        }

        var filterTypes = new List<TypeFilterTypeEntry>();
        foreach (var uniqueTypeId in uniqueTypeIds)
        {
            filterTypes.Add(TypeFilterTypeEntry.FromTypeId(uniqueTypeId));
        }

        // deduplicate mono ids by converting them to global pptrs
        foreach (var uniqueMonoIdPair in uniqueMonoIdPairs)
        {
            var uniqueMonoIdFile = uniqueMonoIdPair.Key;
            var uniqueMonoIds = uniqueMonoIdPair.Value;
            foreach (var uniqueMonoId in uniqueMonoIds)
            {
                var scriptPtr = uniqueMonoIdFile.file.Metadata.ScriptTypes[uniqueMonoId];
                scriptPtr.SetFilePathFromFile(workspace.Manager, uniqueMonoIdFile);

                // SetFilePathFromFile changes hash method to file name
                // rather than file id, so this is fine.
                uniqueScriptPtrs.Add(scriptPtr);
            }
        }

        foreach (var uniqueScriptPtr in uniqueScriptPtrs)
        {
            var scriptTypeRef = GetAssetsFileScriptInfo(workspace.Manager, uniqueScriptPtr);
            if (scriptTypeRef is not null)
            {
                filterTypes.Add(TypeFilterTypeEntry.FromTypeReference(scriptTypeRef));
            }
        }

        var filterTypesSorted = filterTypes
            .OrderBy(a => a.ScriptRef is not null)
            .ThenBy(a => a.DisplayText)
            .ToList();

        return filterTypesSorted;
    }

    public static List<TypeFilterTypeEntry> MakeTypeFilterTypes(Workspace workspace, IList<AssetsFileInstance> fileInsts)
    {
        var filterTypes = new List<TypeFilterTypeEntry>();
        var uniqueTypeIds = new HashSet<int>();
        var uniqueScriptPtrs = new HashSet<AssetPPtr>();

        foreach (var fileInst in fileInsts)
        {
            foreach (var info in fileInst.file.Metadata.AssetInfos)
            {
                if (info.TypeId != 0x72 && info.TypeId >= 0)
                {
                    uniqueTypeIds.Add(info.TypeId);
                }
                else
                {
                    ushort scriptIndex = info.GetScriptIndex(fileInst.file);
                    if (scriptIndex == ushort.MaxValue)
                    {
                        uniqueTypeIds.Add(info.TypeId);
                    }
                    else
                    {
                        uniqueTypeIds.Add(0x72);
                        var scriptPtr = fileInst.file.Metadata.ScriptTypes[scriptIndex];
                        scriptPtr.SetFilePathFromFile(workspace.Manager, fileInst);
                        uniqueScriptPtrs.Add(scriptPtr);
                    }
                }
            }
        }

        foreach (var id in uniqueTypeIds)
        {
            filterTypes.Add(TypeFilterTypeEntry.FromTypeId(id));
        }
        foreach (var ptr in uniqueScriptPtrs)
        {
            var scriptRef = GetAssetsFileScriptInfo(workspace.Manager, ptr);
            if (scriptRef != null) 
                filterTypes.Add(TypeFilterTypeEntry.FromTypeReference(scriptRef));
        }

        return filterTypes.OrderBy(a => a.ScriptRef is not null).ThenBy(a => a.DisplayText).ToList();

    }

    // get script info from global assetpptr rather than script index
    public static AssetTypeReference? GetAssetsFileScriptInfo(AssetsManager manager, AssetPPtr assetPtr)
    {
        if (string.IsNullOrEmpty(assetPtr.FilePath))
            return null;

        AssetTypeValueField msBaseField;
        try
        {
            var fileInst = manager.FileLookup[AssetsManager.GetFileLookupKey(assetPtr.FilePath)];
            msBaseField = manager.GetExtAsset(fileInst, 0, assetPtr.PathId).baseField;
            if (msBaseField == null)
                return null;
        }
        catch
        {
            return null;
        }

        AssetTypeValueField assemblyNameField = msBaseField["m_AssemblyName"];
        AssetTypeValueField nameSpaceField = msBaseField["m_Namespace"];
        AssetTypeValueField classNameField = msBaseField["m_ClassName"];
        if (assemblyNameField.IsDummy || nameSpaceField.IsDummy || classNameField.IsDummy)
            return null;

        string assemblyName = assemblyNameField.AsString;
        string nameSpace = nameSpaceField.AsString;
        string className = classNameField.AsString;

        AssetTypeReference info = new AssetTypeReference(className, nameSpace, assemblyName);
        return info;
    }
}

public partial class TypeFilterTypeEntry : ObservableObject
{
    public string DisplayText { get; set; }
    public int TypeId { get; set; }
    public AssetTypeReference? ScriptRef { get; set; }

    [ObservableProperty]
    public bool _isSelected = false;

    public static TypeFilterTypeEntry FromTypeId(int typeId)
    {
        return new TypeFilterTypeEntry
        {
            TypeId = typeId,
            DisplayText = Enum.GetName(typeof(AssetClassID), typeId)
                ?? $"Unknown #{typeId}",
            ScriptRef = null
        };
    }

    public static TypeFilterTypeEntry FromTypeReference(AssetTypeReference reference)
    {
        return new TypeFilterTypeEntry
        {
            TypeId = 0x72,
            DisplayText = reference.Namespace != ""
                ? $"MB {reference.Namespace}.{reference.ClassName}"
                : $"MB {reference.ClassName}",
            ScriptRef = reference
        };
    }

    public override bool Equals(object? obj)
    {
        if (obj is not TypeFilterTypeEntry otherObj)
            return false;

        if (ScriptRef is null)
        {
            if (otherObj.ScriptRef is null)
                return TypeId == otherObj.TypeId;
        }
        else if (ScriptRef is not null)
        {
            if (otherObj.ScriptRef is not null)
                return ScriptRef.Equals(otherObj.ScriptRef) && TypeId == otherObj.TypeId;
        }

        return false;
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(TypeId, ScriptRef);
    }

    public override string ToString()
    {
        return DisplayText;
    }
}
